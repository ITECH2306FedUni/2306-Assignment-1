package ITECH2306;

import java.util.Scanner;

public class DriverClass 
{

	//public DriverClass() {
		
	//}

	//public void start() { 
		// put code here to create some test objects and test out your system
		//Vehicle v = new Vehicle("Honda", 5);
		//Course c = new Course("Cooking", 8); 
		//Student s = new Student("Kathleen Keogh", "25 somewhere street someplace", "3321", c, v);
		
		//System.out.println(s.toString());
		//System.out.println(s.getVehicle().toString());
		//System.out.println(s.getCourse().toString());
		
	Vehicle v = new Vehicle("Honda", 5);
		

	//}
	public void Vehicle() 
	{
		
		System.out.println("You are doing things about your vehicle 1.Register your vehicle 2.Calculate registion fee");
		Scanner sc = new Scanner(System.in);
		  int input = sc.nextInt();
		  switch(input) 
		  {
		  case 1:
			  v.CheckValid();
			  break;
			  
		  case 2:
			  v.calcRegistrationFee();
			  break;
		  }
		
		
		 
	}
	
	public void Student() 
	{
		
	}
	
	
	public static void main(String[] args) {
		
		
		System.out.println("Welcome to use our system,what would you like to do? 1.Thing about your vehicle");
		
		
		DriverClass d = new DriverClass();  // create DriverClass object ready to use it
		Scanner sc = new Scanner(System.in);
		  d.Vehicle();
		  }
		 // invoke the start method on the object d
		
      
		  
		
		
		
	
		
		
        
	}


