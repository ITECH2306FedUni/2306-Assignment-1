package ITECH2306;

import java.util.Scanner;

public class Vehicle 
{
	private String model;  // e.g. 
	private int age;
	private String registrationID;
	private double fee;
	private boolean valid;
	
	public Vehicle(String _model, int _age) 
	{
		
		this.setModel(_model); // save model for the vehicle
		this.setAge(_age); // save age of the vehicle 
		this.checkIsValid(); // check if this vehicle is permitted to be registered for parking permit
		
	}

	/*
	 * Validate if this vehicle is permitted to be registered for parking on campus
	 */
	
	public void getBKID()
	{

		int maxid = 9999;
		int ogid = 0;
		if(ogid<maxid) 
		{
			ogid++;
			String a = "BK";
			String format = String.format("%04d", ogid);
			System.out.println(a+format);
			registrationID = "BK"+ogid;
		}
		
		
		
	}
		
	public void getMBID()
	{
		int maxid = 9999;
		int ogid = 0;
		if(ogid<maxid) 
		{
			ogid++;
			String a = "MB";
			String format = String.format("%04d", ogid);
			System.out.println(a+format);
			registrationID = "MB"+ogid;
		}
		
		
		
	}
	
	public void getCAID()
	{
		int maxid = 9999;
		int ogid = 0;
		if(ogid<maxid) 
		{
			ogid++;
			String a = "CA";
			String format = String.format("%04d", ogid);
			System.out.println(a+format);
			registrationID = "CA"+ogid;
		}
		
		
		
	}
		
		
	public boolean CheckValid() 
	{
		
		String Bicycle = null;
		String Mobile = null;
		String Car = null;
		
		Scanner s = new Scanner(System.in);
		  int input = s.nextInt();
		  switch(input) 
		  {
		  case 1:
			  System.out.println("Bicycle,its valid and here is your vehicle ID");
			  
			  model = Bicycle;
			  valid = true;
			  getBKID();
			  break;
			  
		  case 2:
		      System.out.println("Mobile,its valid and here is your vehicle ID");
			  model = Mobile;
			  valid = true;
			  getMBID();
			  break;
			  
		  case 3:
			  System.out.println("Is your car foton light truck or wuling hongguang? 1.Yes 2.No");
			  int input1 = s.nextInt();
			  switch(input1) 
			  {
			  case 1:
				  System.out.println("You vehicle is valid so that you cant registered");
				  valid = false;
				  break;
				  
			  case 2:
				  System.out.println("You vehicle is valid and here is your vehicle ID");
				  model = Car;
				  valid = true;
				  getCAID();
				  break;
				  
			  }
			  
		 }
		
		return valid;  // add more code here to test if the vehicle model is valid for parking
	}
	
	
	/*
	 * get the default fee for parking registration for this vehicle
	 */
	
	protected void setModel(String _model) 
	{  // should we be calling checkIsValid from here?
		
		this.model = _model;
	}
	
	protected void SetRegistrationID(String _registrationID) 
	{
		
	
	}
	
	protected void checkIsValid() {  // valid vehicles must in most cases be younger than 5 years old and not be on restricted vehicle list (car)
		if (this.CheckValid() && age < 5)
			setValid(true);
		else
			setValid(false);
			
	}
	
	protected void setValid (boolean myswitch) {
		valid = myswitch;
	}
	
	protected void setAge(int _age) {
		this.age = _age;
		if (this.age >5) // a car over 5 years in age is not allowed to be registered for parking
			valid = false;
	}

	// the public interface to allow other objects to calculate the registration fee (including any discounts)
	/*
	 * @param yearNo : the number of years that this vehicle has been registered previously 
	 */
	public double calcRegistrationFee()
	{
		
		System.out.println("You are calculating fees,please enter what grade you are in��"
				+ "1�� grade 1 , "
				+ "2�� grade 2 ,"
				+ "3 ��grade 3 ");
		
		int input=0;
	      
	     
        
		  Scanner s = new Scanner(System.in);
		  input= s.nextInt();
		 
		  switch(input) 
		  
		  {
		  
		  case 1:
		
			  {
				  System.out.println("You are grade 1 student, please choose your vehicle, "+ "1.bicycle "+ "2 mobile  "+ "3 car");
			  }
		
			  
			  	
			  
			  int grade = s.nextInt();
			  
			  switch(grade) 
			  {
			  case 1:
				  {
					  System.out.println("----------------You vehicle is bicycle,Do you have a licensed electric motor? 1.Yes 2.No---------------");
				  }
				  int i = s.nextInt();
				  switch(i) 
				  {
				  case 1:
				      System.out.println("----------------Your fees are 50----------------");
				      fee = 50;
					  break;
					  
				  case 2:
					  System.out.println("----------------You fees are 100----------------");
					  fee = 50;
					   }
			  break;
			  case 2:
				  System.out.println("----------------You vehicle is mobile and You fees are 175 ----------------");
				  fee = 50;
				  break;
			  case 3:
				  System.out.println("-----------------You vehicle is car and You fees are 250----------------");
				  fee = 50;
				  break;
			  }
			  break;
		  case 2:
			  System.out.println("You are grade 2 student, please choose your vehicle, 1.bicycle , 2��mobile, 3��car");
			  
			  int grade1 = s.nextInt();
			  
			  switch(grade1) 
			  {
			  case 1:
			  {
				  System.out.println("----------------You vehicle is bicycle,Do you have a licensed electric motor? 1.Yes 2.No---------------");
			  }
			  int i = s.nextInt();
			  switch(i) 
			  {
			  case 1:
			      System.out.println("----------------Your fees are 50----------------");
			      fee = 50;
				  break;
				  
			  case 2:
				  System.out.println("-----------------You fees are 100----------------");
				  fee = 50;
				   }
			  break;
			  case 2:
				  System.out.println("----------------You vehicle is mobile and You fees are 173.25 ----------------");
				  fee = 50;
				  break;
			  case 3:
				  System.out.println("-----------------You vehicle is car and You fees are 247.5 ----------------");
				  break;
			  }
		
		     break;
		   
		  case 3:
			  System.out.println("You are grande 3 student, please choose your vehicle, 1.bicycle , 2��mobile, 3��car");
			  
			  int grade2 = s.nextInt();
			  
			  switch(grade2) 
			  {
			  case 1:
			  {
				  System.out.println("----------------You vehicle is bicycle,Do you have a licensed electric motor? 1.Yes 2.No---------------");
			  }
			  int i = s.nextInt();
			  switch(i) 
			  {
			  case 1:
			      System.out.println("----------------Your fees are 50----------------");
			      fee = 50;
				  break;
				  
			  case 2:
				  
				  fee = 100;
				  System.out.println("----------------You fees are 100----------------");
			
				   }
			  break;
			  case 2:
				  System.out.println("----------------You vehicle is mobile and You fees are 169.8 ----------------");
				  fee = 169.8;
				  break;
				  
			  case 3:
			     fee = 242;
				  System.out.println("----------------You vehicle is car and You fees are 242 ----------------");
				
				 
				  break;
			  }
		
		     break;
		  }
		
		return getFee();
	}
	protected double getFee() {
		// get the default fee to use for parking registration
		return this.fee;
	}
	
	
	public String getModel() {
		// get the model of this vehicle
		return this.model;
	}
	
	public int getAge() {
		return this.age;  // get the age and return it
	}
	
	public String GetRegistrationID() 
	{
		
		return this.registrationID;
	}
	
	public String toString() {
		return this.model  + "/" + this.age  + "/" + this.registrationID  + "/" + this.fee;
	}

}
