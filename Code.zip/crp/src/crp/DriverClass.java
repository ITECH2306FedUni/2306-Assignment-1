package crp;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * @author Kathleen Keogh September 2018
 * @author Add in additional author names here
 * 
 */
public class DriverClass {

		
	public DriverClass() {
		
	}

	public void start() { 
		// put code here to create some test objects and test out your system
		Vehicle v = new Vehicle("Toyota", 5);
		Course c = new Course("Cooking", 8); 
		Student s = new Student("Kathleen Keogh", "25 somewhere street someplace", "3321", c, v);
		System.out.println(s.toString());
		System.out.println(s.getVehicle().toString());
		System.out.println(s.getCourse().toString());
		
	}
	//chenruipian 
	public void student() {
		Scanner scan = new Scanner(System.in);
		String name,adress,phoneNumber;
		
		System.out.println("please enter the student name:");
		name=scan.nextLine();
		
		System.out.println("please enter the student address:");
		adress=scan.nextLine();
		
		System.out.println("please enter the student phoneNumber:");
		phoneNumber=scan.nextLine();
	   
		Student s = new Student(name, adress, phoneNumber);
		System.out.println(' ');
		System.out.println("here is your student information ");
		System.out.println("student name:"+s.getName());  
		System.out.println(' ');   
		System.out.println("student address:"+s.getAddress());    
		System.out.println(' ');   
		System.out.println("student phone number:"+s.getPhoneNum());
		
		
	}
	//chenruipian 
	
	public static void addstudent(ArrayList<Student> arry) {		
		Scanner sc= new Scanner(System.in);		
			
							
		System.out.println("please enter the student name��");	
			String name = sc.nextLine();		
		System.out.println("please enter the student address��");		
		String address = sc.nextLine();		
		System.out.println("please enter the student phone number��");	
			String phoneNumber = sc.nextLine();	
			//		
		Student s = new Student();		
		s.setName(name);;		
		s.setAddress(address);;		
		s.setPhoneNumber(phoneNumber);;		
		
			
		arry.add(s);		
		/*System.out.println(' ');
		System.out.println("here is your student information ");
		System.out.println("student name:"+s.getName());  
		System.out.println(' ');   
		System.out.println("student address:"+s.getAddress());    
		System.out.println(' ');   
		System.out.println("student phone number:"+s.getPhoneNum());*/
		
	}
//ruipian chen 
	public static void StudentInformation(ArrayList<Student> arry)
	{
		
		 {		
		if(arry.size()==0) 
		{			
		System.out.println("sorry , now is no student here");			
		return;		
		}		
			
		for(int i=0;i<arry.size();i++) 
		{			
		Student s = arry.get(i);			
		
		
		
		System.out.println("here is your student information ");
		System.out.println("student name:"+s.getName());  
		System.out.println(' ');   
		System.out.println("student address:"+s.getAddress());    
		System.out.println(' ');   
		System.out.println("student phone number:"+s.getPhoneNum());
	}}}//method for finding student information
	//chenruipian 
	public static void Course(ArrayList<Course> arry)
	{
		Scanner sc= new Scanner(System.in);		
			
							
		System.out.println("please enter the course name��");	
			String name = sc.nextLine();		
		System.out.println("please enter the course running days��");		
		int days = sc.nextInt();		
		System.out.println("please enter the course price��");		
		double price = sc.nextInt();
		Course c = new Course( );
		
		c.setName(name);
		c.setNumDaysRunning(days);
		c.setPrice(price);
		/*System.out.println("course name:"+c.getName());
		System.out.println("course running days:"+c.getMaxDays());
		System.out.println("course price:"+c.getPrice());*/
		arry.add(c);
		
		
		/*Scanner scan = new Scanner(System.in);
		
		String name;
		int numDaysRunning;
		System.out.println("please enter the course name:");
		name=scan.nextLine();
		
		System.out.println("How many days running this course:");
		numDaysRunning=scan.nextInt();
		
		
	
		Course c = new Course(name,numDaysRunning );
		System.out.println("course name:"+c.getName());
		System.out.println("course running days:"+c.getMaxDays());*/
	}
	//chenruipian 
	
	public static void CourseInformation(ArrayList<Course> arry)
	{
		
		 {		
		if(arry.size()==0) 
		{			
		System.out.println("sorry , now is no course here");			
		return;		
		}		
			
		for(int i=0;i<arry.size();i++) 
		{			
		Course s = arry.get(i);			
		
		
		
		System.out.println("here is the course information ");
		System.out.println("student name:"+s.getName());  
		System.out.println("course days:"+s.getMaxDays());
		System.out.println("course price:"+s.getPrice());
	
	}}}
	
	
	public static void studentCourse(ArrayList<Student> arry)
	{
       
		Scanner sc= new Scanner(System.in);		
		
		
		System.out.println("please enter your name��");	
			String name = sc.nextLine();		
			
		System.out.println("please enter the course that you wanted to enroll��");	
			String course = sc.nextLine();	
			
			//		
		Student s = new Student();		
		s.setName(name);;		
		Course c=new Course(name,5,5);
		s.enrolInCourse(c);		
		
			
		arry.add(s);		
		System.out.println(' ');
		System.out.println("here is your student information ");
		System.out.println("student name:"+s.getName());     
		System.out.println(' ');   
		System.out.println("student phone number:"+s.getCourse());
		
		System.out.println("here is your invoice:"+s.getCourse().getPrice());
		
	}
	
	void showMenu(){    
		  
	System.out.println(' ');    
	System.out.println('*');   
	
	System.out.println(' ');  
	System.out.println("--welcome to our system");  
	System.out.println(' ');   
	System.out.println("--you can choose use the system as student or manage");    
	System.out.println(' ');    
	System.out.println("--1,AS A MANAGE                         2, AS A STUDENT");    

	
	}
	//chenruipian 
	void MANGmenu()
	{
		System.out.println(' ');  
		System.out.println("--1,Student registration");  
		System.out.println(' ');   
		System.out.println("--2,Vehicle registration");    
		System.out.println(' ');    
		System.out.println("--3,Course registration");    
	}
	//chenruipian 
	public void menu()
	{
		DriverClass d = new DriverClass();
		Scanner input=new Scanner(System.in);
	    d.showMenu();
	    int num0=0;
	    ArrayList<crp.Course> arry = new ArrayList<>();
	    ArrayList<crp.Student> arry1 = new ArrayList<>();
		int num1=input.nextInt();
		
		
		switch(num1){
		case 1:
			System.out.println("AS A MANAGE");
			d.MANGmenu();
			int num2=input.nextInt();
			
			switch(num2){
			case 1:
				System.out.println("Student registration");
				d.addstudent(arry1);		
				System.out.println("1,information of student");
				int num3=input.nextInt();
				switch(num3){
				case 1:
			    d.StudentInformation(arry1);
				}
			case 2:
				System.out.println("Vehicle registration");
				break;
			case 3:
				System.out.println("Course registration");
				d.Course(arry);
				System.out.println("1,information of Course");
				int num4=input.nextInt();
				switch(num4)
				{
				case 1:
					d.CourseInformation(arry);
				}
				//chenruipian 
		break;
			default:
				System.out.println("error��");
				break;
			}
			break;
		case 2:
              System.out.println("1.Course eroll");
             System.out.println("2.Vehicle eroll");
             int num5=input.nextInt();
            
             
			  switch(num5){
			  case 1:
				System.out.println("Course eroll");
				d.studentCourse(arry1);			    
		        break;
			  case 2:
				  System.out.println("Vehicle eroll");
				  break;//your part
			  }
			  break;
		default:
				System.out.println("error��");
				break;
		}
		}
	//chenruipian 
	

	
	public static void main(String[] args) {
		DriverClass d = new DriverClass();  // create DriverClass object ready to use it
		d.menu();
		Course c = new Course("Cooking", 8);            
		Course a = new Course("IT", 5); 
		Course e = new Course("English", 7); 
		Course f = new Course("Chinese", 9); 
	}

}
