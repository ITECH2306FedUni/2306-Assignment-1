package crp;
import java.io.*;
import java.util.*;
import java.util.Scanner;/**
 * @author kkeogh
 * @version 1.0
 * @created 21-Sep-2018 4:55:46 PM
 * Add in additional author details here
 * 
 */
public class Student  
{

	private String name;  // name of person
	private String address; // address of person
	private String postcode; // postcode of person's address
	private String studentID; // unique student ID
	private String city;
	private Course courseEnrolledIn; // course this student is enrolled in
	private Vehicle myVehicle;  // vehicle owned by this student
	private String phoneNumber;
	private static int nextAvailStudentID=0;
	int S;
	/**
	 * 
	 * @param _name
	 * @param _address
	 * @param _postcode
	 * @param _courseEnrolledIn
	 * @param _phoneNo
	 * @param _myRatePayer
	 */	
	//Author Ruipian Chen 
	public Student(String _name, String _address, String _postcode, Course _courseEnrolledIn, Vehicle _myVehicle ){
		super();
		this.setName(_name);
		this.setAddress(_address);
		this.setPostcode(_postcode);
		this.enrolInCourse(_courseEnrolledIn);
		this.city = "MyCITY";
		this.myVehicle = _myVehicle;
		this.generateStudentID();
	}
	//Author Ruipian Chen
	public Student()
	{
		
	}

	/**
	 * 
	 * @param _name
	 * @param _address
	 * @param _postcode
	 * @param _phoneNo
	 * @param _myRatePayer
	 * @param _myVehicle
	 */
	//Author Ruipian Chen
	public Student(String _name, String _address, String _postcode, Course _courseEnrolledIn, Vehicle _myVehicle ,String phoneNumber)
	{
		super();
		this.setName(_name);
		this.setAddress(_address);
		this.setPostcode(_postcode);
		this.enrolInCourse(_courseEnrolledIn);
		this.city = "MyCITY";
		this.myVehicle = _myVehicle;
		this.generateStudentID();
		this.setPhoneNumber(phoneNumber);
	}//TODO add new overloaded constructor here to allow to create a student with the optional phone number
	


	//Author Ruipian Chen
	public Student(String _name, String _address, String _phoneNo)
{
		super();
		this.setName(_name);
		this.setAddress(_address);
	    this.setPhoneNumber(_phoneNo);
		
	    this.generateStudentID();
		
	}
	
	/**
	 * 
	 * @param _name
	 * @param _address
	 * @param _postcode
	 * @param _phoneNo
	 * @param _myRatePayer
	 */
	public Student(String _name, String _address, String _postcode, String _phoneNo)
	{
		super();
		this.setName(_name);
		this.setAddress(_address);
		this.setPostcode(_postcode);
		this.courseEnrolledIn = null;
		this.myVehicle = null;
		this.city = "MyCITY";
		this.generateStudentID();
	}
	////Author Ruipian Chen

	protected void generateStudentID() 
	{
		
      
		
		// TODO put code here to automatically generate a new student ID
		if(nextAvailStudentID <201900) {
			nextAvailStudentID = 201900;
			
			studentID=String.valueOf(nextAvailStudentID);//ruipian chen
			System.out.println("Here is your student ID: "+studentID);
					
		}
		else {
			
			nextAvailStudentID++;
			
			
			studentID=String.valueOf(nextAvailStudentID);//ruipian chen
			System.out.println("Here is your student ID"+studentID);//ruipian chen
			
		}
		
	}
	//Author Ruipian Chen
	
	public Vehicle getVehicle() 
	{
		
		return this.myVehicle;
	}
	////Author Ruipian Chen 

	public Course getCourse() 
	{
		return this.courseEnrolledIn;
	}
	//chenruipian 
	protected void setPostcode(String _postcode) 
	{
		
		////Author Ruipian Chen
		/*char[] chs = new char[100];
		String str;
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter your postcode��");
		str = sc.nextLine();
		System.out.println();
		for (int i = 0; i < str.length(); i ++)
		{
		chs[i] = str.charAt(i);
		System.out.print(chs[i] + " ");
		}*/
		
		//ruipian chen
		
		// save _postcode to the postcode attribute on this Student
		this.postcode = _postcode;
	}
	//Author Ruipian Chen
	protected void setPhoneNumber(String _phoneNumber) 
	{
		
		// TODO Auto-generated method stub
		this.phoneNumber = _phoneNumber;
	}
	//chenruipian 
	protected void setAddress(String _address) 
	{
		//Author Ruipian Chen
		
				/*char[] chs = new char[100];
				String str;
				Scanner sc = new Scanner(System.in);
				System.out.print("Please Enter your address��");
				str = sc.nextLine();
				System.out.println();
				for (int i = 0; i < str.length(); i ++)
				{
				chs[i] = str.charAt(i);
				System.out.print(chs[i] + " ");
				}*/
		
				//ruipian chen
				// save _address to the address attribute on this Student
		this.address = _address;
	}
	//chenruipian 

	protected void setName(String _name) 
	{
		// save _name to the name attribute on this Student
		this.name = _name;
	}
	//chenruipian 

	public String getName() 
	{
		// get the name of this student
		return this.name;
	}
	
	public String getAddress() 
	{
		// get the name of this student
		return this.address;
	}
	
	public String getPhoneNum() 
	{
		// get the name of this student
		return this.phoneNumber;
	}
	//Author Ruipian Chen
	
	public void enrolInCourse(Course _aCourse)
	{
		// This method will enrol this student in the given course: _aCourse
		// tell the course object to add this student to the student list
		
		// if all was fine with enrolment in the course,
		// save the course object in this student's courseEnrolledIn attribute
		if(_aCourse.enrolInCourse(this)) {
			this.courseEnrolledIn = _aCourse;
		}

	}

	public String generateCourseInvoice()
	{  // create a String with details of the invoice for this student based on course enrolled in
		return "";
	}

	
	private boolean hasRegisteredVehicle() 
	{
		return (this.myVehicle != null);
	}
	
	boolean registerVehicle(Vehicle _vehicle) {
		if (_vehicle.isValid()) { // validate if this vehicle is permitted to be registered
			this.myVehicle = _vehicle;
			return true;
			}
		else return false;
	
	}



	public String generateRegistrationInvoice() 
	{
		// TODO complete this method - calculate the fees and create an invoice as a string
		return " Invoice for parking registration : \n currently empty ";
	}

	public String toString() 
	{
		return "Student/" + name + "/" + address + "/" + postcode; // put more useful information in this string
	}

	
	
}//end Student