package crp;
/*
 * @author Kathleen Keogh September 2018
 * @author Add in additional author names here
 * 
 */
public class Vehicle {

	private String model;  // e.g. 
	private int age;
	private String registrationID;
	private double fee;
	private boolean valid;
	
	public Vehicle(String _model, int _age) {
		
		this.setModel(_model); // save model for the vehicle
		this.setAge(_age); // save age of the vehicle 
		this.checkIsValid(); // check if this vehicle is permitted to be registered for parking permit
		
	}

	/*
	 * Validate if this vehicle is permitted to be registered for parking on campus
	 */
	public boolean isValid() {
		return valid;  // add more code here to test if the vehicle model is valid for parking
	}
	
	/*
	 * get the default fee for parking registration for this vehicle
	 */
	protected double getFee() {
		// get the default fee to use for parking registration
		return this.fee;
	}
	
	protected void setModel(String _model) {  // should we be calling checkIsValid from here?
		this.model = _model;
	}
	
	protected void SetRegistrationID(String _registrationID) {
		this.registrationID = _registrationID;
	}
	
	protected void checkIsValid() {  // valid vehicles must in most cases be younger than 5 years old and not be on restricted vehicle list (car)
		if (this.isValid() && age < 5)
			setValid(true);
		else
			setValid(false);
			
	}
	
	protected void setValid (boolean myswitch) {
		valid = myswitch;
	}
	
	protected void setAge(int _age) {
		this.age = _age;
		if (this.age >5) // a car over 5 years in age is not allowed to be registered for parking
			valid = false;
	}

	// the public interface to allow other objects to calculate the registration fee (including any discounts)
	/*
	 * @param yearNo : the number of years that this vehicle has been registered previously 
	 */
	public double calcRegistrationFee(int yearNo){  		/**
		 * The college will apply a discount for each year of registration. The discount accumulates and is applied to last year's fee.
		 * So, if a vehicle has been registered for 3 years in 2018, the fee is calculated with a discount 3 * 10 off the fee.
		 *      the fee is 2017 is calculated as a discount of subtracting 3 *10 init fee)
		 * If first year of registration :
		    fee = INITFEE
		   else : 
		    initialise last year's fee = INITFEE
		    repeat this Loop for each year since first registration :  
		            Discount = 10 * number of years registered  (so this increases each year)
		            calculate fee as:  last year's fee less discount
		            update last year's fee to equal fee ready for next iteration through loop
		 */		
		if(yearNo <=1) {
			// No change
		} else {
			this.fee = this.fee - (yearNo *5);
		}
		return getFee();
	}
	
	public String getModel() {
		// get the model of this vehicle
		return this.model;
	}
	
	public int getAge() {
		return this.age;  // get the age and return it
	}
	
	public String GetRegistrationID() {
		return this.registrationID;
	}
	
	public String toString() {
		return this.model  + "/" + this.age  + "/" + this.registrationID  + "/" + this.fee;
	}
}
