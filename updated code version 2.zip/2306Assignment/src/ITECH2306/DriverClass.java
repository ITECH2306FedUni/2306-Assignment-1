package ITECH2306;

import java.util.Scanner;

public class DriverClass 
{

	static Scanner sc = new Scanner(System.in);
	  static int scan_num= sc.nextInt();
	String Stu[] =new String [100];
	static  int number=0;
	public DriverClass() {
		
	}

	public void start() { 
		 //put code here to create some test objects and test out your system
		Vehicle v = new Vehicle("Honda", 5);
		Course c = new Course("Cooking", 8); 
		Student s = new Student("Kathleen Keogh", "25 somewhere street someplace", "3321", c, v);
		
		System.out.println(s.toString());
	System.out.println(s.getVehicle().toString());
		System.out.println(s.getCourse().toString());
		
	
		

	
	
	}
	public void add() 
	{
		
	
		}
	
		
		
		
		
		
		
		
	
	
	public static void Vehicle() 
	{
		Vehicle v = new Vehicle("Honda", 5);
		
		System.out.println("What would you like to do? 1.Back to last menu 2.Calculate your fee ");
		
		
		  switch(scan_num) 
		  {
		  case 1:
			v.checkIsValid();
			break;
		  case 2:
			 
			  v.calcRegistrationFee();
			  break;
		  }
	
		
		  return;
	}
	
	public static void student() 
	{
		System.out.println("You are registing as a new student,press any word for continue,0 for exit");
		String [] stu = new String[100];
		Scanner sc = new Scanner(System.in);
		  int scan_num= sc.nextInt();
		
		
		switch(scan_num) 
		{
		case 1:	System.out.println("Please enter your name");
		String name=sc.next();
		
		System.out.println("Please enter your postcode");
		String postcode = sc.next();
		
		System.out.println("Please enter your address");
		String address = sc.next();
		
		Student student =new Student( name, postcode,  address, null);
		
		System.out.println("Your name is" + name+" Your student postcode is "+postcode+ " Your address is "+ address);
		
		if(scan_num == 0);
		break;
		}
		
		
	}
	
	public static void main(String[] args) 
	{
		System.out.println("Welcome to use our system,what would you like to do? 1.Registerd as a new student 2.Register your vehicle 3.Exit");
		int choice;
		DriverClass d = new DriverClass(); 
		while(true) {
		
		choice=sc.nextInt();
		  if(choice==0)break;
	switch(choice) 
	{
	case 1:
	    student();
		break;
		
	case 2:
		Vehicle();
		break;
	}
	
			
		}
		
		
		}
	
		 
		  }
		 // invoke the start method on the object d
		
      
		  
		
		
		
	
		
		
        
	


