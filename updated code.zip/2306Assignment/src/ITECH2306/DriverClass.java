package ITECH2306;

import java.util.Scanner;

public class DriverClass 
{

	//public DriverClass() {
		
	//}

	//public void start() { 
		// put code here to create some test objects and test out your system
		//Vehicle v = new Vehicle("Honda", 5);
		//Course c = new Course("Cooking", 8); 
		//Student s = new Student("Kathleen Keogh", "25 somewhere street someplace", "3321", c, v);
		
		//System.out.println(s.toString());
		//System.out.println(s.getVehicle().toString());
		//System.out.println(s.getCourse().toString());
		
	
		

	
	
	//}
	

	public void Vehicle() 
	{
		Vehicle v = new Vehicle("Honda", 5);
		
		System.out.println("What would you like to do? 1.Back to last menu 2.Calculate your fee ");
		
		Scanner sc = new Scanner(System.in);
		  int input = sc.nextInt();
		  switch(input) 
		  {
		  case 1:
			v.checkIsValid();
			break;
		  case 2:
			 
			  v.calcRegistrationFee();
			  break;
		  }
	
		
		  return;
	}
	
	public void student() 
	{
		
	}
	
	public static void main(String[] args) 
	{
		
		DriverClass d = new DriverClass(); 
		
		
		
		  // create DriverClass object ready to use it
		
		
		System.out.println("Welcome to use our system,what would you like to do? 1.Registerd as a new student 2.Register your vehicle");
		Scanner sc = new Scanner(System.in);
		int input = sc.nextInt();
		{
		  switch(input) 
		  {
		  case 1: 
			  d.student();
		      break;
			  
		  case 2:
			  d.Vehicle();
			  break;
		  }
			
		}
		 
		  }
		 // invoke the start method on the object d
		
      
		  
		
		
		
	
		
		
        
	}


